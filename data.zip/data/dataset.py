#!/usr/bin/env python
import rospy
import atexit
from sensor_msgs.msg import LaserScan
from ackermann_msgs.msg import AckermannDriveStamped

actions_file = open('actions.txt', 'w')
lidar_file = open('lidar.txt', 'w')
prev_cmd = None

def load_cmd(data):

    global prev_cmd
    steer = data.drive.steering_angle
    speed = data.drive.speed
    prev_cmd = (steer, speed)

def load_lidar(data):

    if prev_cmd:

        ang, steer = prev_cmd
        actions_file.write('{} {}\n'.format(ang, steer))

        lidar = list(map(str, data.ranges))
        lidar_string = ' '.join(lidar) + '\n'
        lidar_file.write(lidar_string)

        print('Data point stored')


def shutdown():
    actions_file.close()
    lidar_file.close()
    print('End')

def listener():
    rospy.init_node('save_to_dataset', anonymous=True)
    rospy.Subscriber('/ackermann_cmd', AckermannDriveStamped, load_cmd)
    rospy.Subscriber('/scan', LaserScan, load_lidar)
    rospy.spin()

if __name__ == '__main__':
    atexit.register(shutdown)
    print('Saving recorded data...')
    try:
        listener()
    except rospy.ROSInterruptException:
        pass
